# Teams Kolléga 2.0
AI alapú támogatói rendszer Microsoft Teams felhasználóknak.
